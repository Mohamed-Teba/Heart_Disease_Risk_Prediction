# Utility functions for data processing
