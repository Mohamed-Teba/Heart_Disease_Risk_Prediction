Accuracy Comparison Report

This report compares the performance of different Machine Learning models used for heart disease detection.

Models Evaluated:

Decision Tree

Random Forest

Support Vector Machine (SVM)

Logistic Regression


Accuracy Results:

Visualization



Conclusion

The Random Forest model achieved the highest accuracy and is recommended for deployment.

