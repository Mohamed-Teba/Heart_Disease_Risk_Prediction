# Train Decision Tree model
