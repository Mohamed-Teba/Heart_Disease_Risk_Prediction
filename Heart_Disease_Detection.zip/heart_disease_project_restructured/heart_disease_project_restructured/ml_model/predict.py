# Predict using trained model
